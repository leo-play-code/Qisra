// 上傳功能還未有功能
// function _Ckeditor_replace(DOM){
//     // detect edit hidden or not
//     if (Edit_teststep_btn.classList.contains('hidden')){
//         // close all 
//         for(data in CKEDITOR.instances)
//         {
//             console.log(CKEDITOR.instances[data].getData())
//             CKEDITOR.instances[data].destroy(true);
//         }
//         ckeditor_temp = CKEDITOR.replace(DOM);
//         ckeditor_temp.on('blur', function(e)
//         {
//             if (e.editor.checkDirty()) {
//                 dataTransferComplete=e.editor.getData()
//                 console.log(dataTransferComplete)
//                 if ( dataTransferComplete ) {
//                     e.editor.destroy();
//                 }else {
//                     e.editor.destroy();
//                 }
//             }
//         });
//     }   
// }

